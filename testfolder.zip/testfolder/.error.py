keyboard.send_keys('.error("");')
keyboard.send_keys("<left>"*3)