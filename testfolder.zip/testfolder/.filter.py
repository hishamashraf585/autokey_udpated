keyboard.send_keys(""".filter((element) => )""")
keyboard.send_keys("<left>"*2)