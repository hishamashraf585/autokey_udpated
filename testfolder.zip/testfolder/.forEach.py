keyboard.send_keys(""".forEach(function (element) {});""")
keyboard.send_keys("<left>"*3)