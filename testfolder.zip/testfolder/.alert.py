keyboard.send_keys(".alert()")
keyboard.send_keys("<left>"*1)